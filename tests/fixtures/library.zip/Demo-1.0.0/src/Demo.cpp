#include "Demo.h"
int answer(){return 42;}
